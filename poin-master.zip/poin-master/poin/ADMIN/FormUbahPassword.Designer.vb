﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormUbahPassword
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim CustomizableEdges1 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim CustomizableEdges2 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim CustomizableEdges3 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim CustomizableEdges4 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim CustomizableEdges5 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim CustomizableEdges6 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim CustomizableEdges7 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim CustomizableEdges8 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim resources As ComponentModel.ComponentResourceManager = New ComponentModel.ComponentResourceManager(GetType(FormUbahPassword))
        TextBoxPassLama = New Guna.UI2.WinForms.Guna2TextBox()
        TextBoxPassBaru = New Guna.UI2.WinForms.Guna2TextBox()
        TextBoxPassKon = New Guna.UI2.WinForms.Guna2TextBox()
        ButtonUbahPass = New Button()
        textuser = New Guna.UI2.WinForms.Guna2TextBox()
        SuspendLayout()
        ' 
        ' TextBoxPassLama
        ' 
        TextBoxPassLama.CustomizableEdges = CustomizableEdges1
        TextBoxPassLama.DefaultText = ""
        TextBoxPassLama.DisabledState.BorderColor = Color.FromArgb(CByte(208), CByte(208), CByte(208))
        TextBoxPassLama.DisabledState.FillColor = Color.FromArgb(CByte(226), CByte(226), CByte(226))
        TextBoxPassLama.DisabledState.ForeColor = Color.FromArgb(CByte(138), CByte(138), CByte(138))
        TextBoxPassLama.DisabledState.PlaceholderForeColor = Color.FromArgb(CByte(138), CByte(138), CByte(138))
        TextBoxPassLama.FocusedState.BorderColor = Color.FromArgb(CByte(94), CByte(148), CByte(255))
        TextBoxPassLama.Font = New Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point)
        TextBoxPassLama.HoverState.BorderColor = Color.FromArgb(CByte(94), CByte(148), CByte(255))
        TextBoxPassLama.Location = New Point(25, 134)
        TextBoxPassLama.Name = "TextBoxPassLama"
        TextBoxPassLama.PasswordChar = ChrW(0)
        TextBoxPassLama.PlaceholderText = "pass lama"
        TextBoxPassLama.SelectedText = ""
        TextBoxPassLama.ShadowDecoration.CustomizableEdges = CustomizableEdges2
        TextBoxPassLama.Size = New Size(406, 54)
        TextBoxPassLama.TabIndex = 0
        TextBoxPassLama.TextAlign = HorizontalAlignment.Center
        ' 
        ' TextBoxPassBaru
        ' 
        TextBoxPassBaru.CustomizableEdges = CustomizableEdges3
        TextBoxPassBaru.DefaultText = ""
        TextBoxPassBaru.DisabledState.BorderColor = Color.FromArgb(CByte(208), CByte(208), CByte(208))
        TextBoxPassBaru.DisabledState.FillColor = Color.FromArgb(CByte(226), CByte(226), CByte(226))
        TextBoxPassBaru.DisabledState.ForeColor = Color.FromArgb(CByte(138), CByte(138), CByte(138))
        TextBoxPassBaru.DisabledState.PlaceholderForeColor = Color.FromArgb(CByte(138), CByte(138), CByte(138))
        TextBoxPassBaru.FocusedState.BorderColor = Color.FromArgb(CByte(94), CByte(148), CByte(255))
        TextBoxPassBaru.Font = New Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point)
        TextBoxPassBaru.HoverState.BorderColor = Color.FromArgb(CByte(94), CByte(148), CByte(255))
        TextBoxPassBaru.Location = New Point(25, 224)
        TextBoxPassBaru.Name = "TextBoxPassBaru"
        TextBoxPassBaru.PasswordChar = ChrW(0)
        TextBoxPassBaru.PlaceholderText = "pass baru"
        TextBoxPassBaru.SelectedText = ""
        TextBoxPassBaru.ShadowDecoration.CustomizableEdges = CustomizableEdges4
        TextBoxPassBaru.Size = New Size(406, 54)
        TextBoxPassBaru.TabIndex = 1
        TextBoxPassBaru.TextAlign = HorizontalAlignment.Center
        ' 
        ' TextBoxPassKon
        ' 
        TextBoxPassKon.CustomizableEdges = CustomizableEdges5
        TextBoxPassKon.DefaultText = ""
        TextBoxPassKon.DisabledState.BorderColor = Color.FromArgb(CByte(208), CByte(208), CByte(208))
        TextBoxPassKon.DisabledState.FillColor = Color.FromArgb(CByte(226), CByte(226), CByte(226))
        TextBoxPassKon.DisabledState.ForeColor = Color.FromArgb(CByte(138), CByte(138), CByte(138))
        TextBoxPassKon.DisabledState.PlaceholderForeColor = Color.FromArgb(CByte(138), CByte(138), CByte(138))
        TextBoxPassKon.FocusedState.BorderColor = Color.FromArgb(CByte(94), CByte(148), CByte(255))
        TextBoxPassKon.Font = New Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point)
        TextBoxPassKon.HoverState.BorderColor = Color.FromArgb(CByte(94), CByte(148), CByte(255))
        TextBoxPassKon.Location = New Point(25, 311)
        TextBoxPassKon.Name = "TextBoxPassKon"
        TextBoxPassKon.PasswordChar = ChrW(0)
        TextBoxPassKon.PlaceholderText = "ulang pass baru"
        TextBoxPassKon.SelectedText = ""
        TextBoxPassKon.ShadowDecoration.CustomizableEdges = CustomizableEdges6
        TextBoxPassKon.Size = New Size(406, 54)
        TextBoxPassKon.TabIndex = 2
        TextBoxPassKon.TextAlign = HorizontalAlignment.Center
        ' 
        ' ButtonUbahPass
        ' 
        ButtonUbahPass.BackColor = Color.LimeGreen
        ButtonUbahPass.Font = New Font("Arial", 10F, FontStyle.Bold, GraphicsUnit.Point)
        ButtonUbahPass.Location = New Point(122, 380)
        ButtonUbahPass.Name = "ButtonUbahPass"
        ButtonUbahPass.Size = New Size(210, 58)
        ButtonUbahPass.TabIndex = 3
        ButtonUbahPass.Text = "ubah"
        ButtonUbahPass.UseVisualStyleBackColor = False
        ' 
        ' textuser
        ' 
        textuser.CustomizableEdges = CustomizableEdges7
        textuser.DefaultText = ""
        textuser.DisabledState.BorderColor = Color.FromArgb(CByte(208), CByte(208), CByte(208))
        textuser.DisabledState.FillColor = Color.FromArgb(CByte(226), CByte(226), CByte(226))
        textuser.DisabledState.ForeColor = Color.FromArgb(CByte(138), CByte(138), CByte(138))
        textuser.DisabledState.PlaceholderForeColor = Color.FromArgb(CByte(138), CByte(138), CByte(138))
        textuser.FocusedState.BorderColor = Color.FromArgb(CByte(94), CByte(148), CByte(255))
        textuser.Font = New Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point)
        textuser.HoverState.BorderColor = Color.FromArgb(CByte(94), CByte(148), CByte(255))
        textuser.Location = New Point(25, 45)
        textuser.Name = "textuser"
        textuser.PasswordChar = ChrW(0)
        textuser.PlaceholderText = "Username"
        textuser.SelectedText = ""
        textuser.ShadowDecoration.CustomizableEdges = CustomizableEdges8
        textuser.Size = New Size(406, 54)
        textuser.TabIndex = 4
        textuser.TextAlign = HorizontalAlignment.Center
        ' 
        ' FormUbahPassword
        ' 
        AutoScaleDimensions = New SizeF(10F, 25F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = Color.Black
        ClientSize = New Size(458, 450)
        Controls.Add(textuser)
        Controls.Add(ButtonUbahPass)
        Controls.Add(TextBoxPassKon)
        Controls.Add(TextBoxPassBaru)
        Controls.Add(TextBoxPassLama)
        Icon = CType(resources.GetObject("$this.Icon"), Icon)
        Name = "FormUbahPassword"
        StartPosition = FormStartPosition.CenterScreen
        Text = "FormUbahPassword"
        ResumeLayout(False)
    End Sub

    Friend WithEvents TextBoxPassLama As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents TextBoxPassBaru As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents TextBoxPassKon As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents ButtonUbahPass As Button
    Friend WithEvents textuser As Guna.UI2.WinForms.Guna2TextBox
End Class
