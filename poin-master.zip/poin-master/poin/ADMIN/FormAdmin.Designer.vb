﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormAdmin
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim CustomizableEdges1 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim CustomizableEdges2 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim CustomizableEdges3 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim CustomizableEdges4 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim CustomizableEdges5 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim CustomizableEdges6 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim resources As ComponentModel.ComponentResourceManager = New ComponentModel.ComponentResourceManager(GetType(FormAdmin))
        Dim CustomizableEdges7 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim CustomizableEdges8 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim CustomizableEdges9 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim CustomizableEdges10 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim CustomizableEdges11 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim CustomizableEdges12 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim CustomizableEdges13 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim CustomizableEdges14 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim CustomizableEdges15 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim CustomizableEdges16 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim CustomizableEdges17 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim CustomizableEdges18 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim CustomizableEdges19 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim CustomizableEdges20 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim CustomizableEdges21 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim CustomizableEdges22 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim CustomizableEdges23 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim CustomizableEdges24 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim CustomizableEdges25 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim CustomizableEdges26 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Panel1 = New Panel()
        Guna2GradientButton3 = New Guna.UI2.WinForms.Guna2GradientButton()
        Guna2GradientButton2 = New Guna.UI2.WinForms.Guna2GradientButton()
        Guna2GradientButton1 = New Guna.UI2.WinForms.Guna2GradientButton()
        PictureBox1 = New PictureBox()
        TableLayoutPanel1 = New TableLayoutPanel()
        btnLogout = New Guna.UI2.WinForms.Guna2GradientButton()
        btnLaporan = New Guna.UI2.WinForms.Guna2GradientButton()
        btnKelolaStok = New Guna.UI2.WinForms.Guna2GradientButton()
        btnKelolaProduk = New Guna.UI2.WinForms.Guna2GradientButton()
        btnKelolaUsers = New Guna.UI2.WinForms.Guna2GradientButton()
        Panel2 = New Panel()
        TableLayoutPanel3 = New TableLayoutPanel()
        TableLayoutPanel4 = New TableLayoutPanel()
        Panel10 = New Panel()
        Label7 = New Label()
        Label8 = New Label()
        Panel11 = New Panel()
        Label9 = New Label()
        Label10 = New Label()
        Panel3 = New Panel()
        TableLayoutPanel5 = New TableLayoutPanel()
        DataGridView1 = New DataGridView()
        Column1 = New DataGridViewTextBoxColumn()
        Column2 = New DataGridViewTextBoxColumn()
        Column3 = New DataGridViewTextBoxColumn()
        Column4 = New DataGridViewTextBoxColumn()
        Panel12 = New Panel()
        Guna2GradientButton8 = New Guna.UI2.WinForms.Guna2GradientButton()
        Label13 = New Label()
        LabelJumlahBulan = New Label()
        Panel9 = New Panel()
        Guna2GradientButton9 = New Guna.UI2.WinForms.Guna2GradientButton()
        Label11 = New Label()
        LabelJumlahHari = New Label()
        Panel5 = New Panel()
        TableLayoutPanel2 = New TableLayoutPanel()
        Panel7 = New Panel()
        Guna2GradientButton5 = New Guna.UI2.WinForms.Guna2GradientButton()
        Label3 = New Label()
        LabelBulanIni = New Label()
        Panel8 = New Panel()
        Guna2GradientButton6 = New Guna.UI2.WinForms.Guna2GradientButton()
        Label5 = New Label()
        LabelJumlahTransaksi = New Label()
        Panel6 = New Panel()
        Guna2GradientButton4 = New Guna.UI2.WinForms.Guna2GradientButton()
        Label2 = New Label()
        LabelHariIni = New Label()
        Panel4 = New Panel()
        Panel1.SuspendLayout()
        CType(PictureBox1, ComponentModel.ISupportInitialize).BeginInit()
        TableLayoutPanel1.SuspendLayout()
        TableLayoutPanel4.SuspendLayout()
        Panel10.SuspendLayout()
        Panel11.SuspendLayout()
        Panel3.SuspendLayout()
        TableLayoutPanel5.SuspendLayout()
        CType(DataGridView1, ComponentModel.ISupportInitialize).BeginInit()
        Panel12.SuspendLayout()
        Panel9.SuspendLayout()
        TableLayoutPanel2.SuspendLayout()
        Panel7.SuspendLayout()
        Panel8.SuspendLayout()
        Panel6.SuspendLayout()
        SuspendLayout()
        ' 
        ' Panel1
        ' 
        Panel1.Controls.Add(Guna2GradientButton3)
        Panel1.Controls.Add(Guna2GradientButton2)
        Panel1.Controls.Add(Guna2GradientButton1)
        Panel1.Controls.Add(PictureBox1)
        Panel1.Controls.Add(TableLayoutPanel1)
        Panel1.Dock = DockStyle.Top
        Panel1.Location = New Point(0, 0)
        Panel1.Name = "Panel1"
        Panel1.Size = New Size(1191, 90)
        Panel1.TabIndex = 0
        ' 
        ' Guna2GradientButton3
        ' 
        Guna2GradientButton3.Anchor = AnchorStyles.Top Or AnchorStyles.Left Or AnchorStyles.Right
        Guna2GradientButton3.CustomizableEdges = CustomizableEdges1
        Guna2GradientButton3.DisabledState.BorderColor = Color.DarkGray
        Guna2GradientButton3.DisabledState.CustomBorderColor = Color.DarkGray
        Guna2GradientButton3.DisabledState.FillColor = Color.FromArgb(CByte(169), CByte(169), CByte(169))
        Guna2GradientButton3.DisabledState.FillColor2 = Color.FromArgb(CByte(169), CByte(169), CByte(169))
        Guna2GradientButton3.DisabledState.ForeColor = Color.FromArgb(CByte(141), CByte(141), CByte(141))
        Guna2GradientButton3.FillColor = Color.Black
        Guna2GradientButton3.FillColor2 = Color.FromArgb(CByte(255), CByte(128), CByte(0))
        Guna2GradientButton3.Font = New Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point)
        Guna2GradientButton3.ForeColor = Color.White
        Guna2GradientButton3.Location = New Point(188, 72)
        Guna2GradientButton3.Name = "Guna2GradientButton3"
        Guna2GradientButton3.ShadowDecoration.CustomizableEdges = CustomizableEdges2
        Guna2GradientButton3.Size = New Size(125, 10)
        Guna2GradientButton3.TabIndex = 5
        ' 
        ' Guna2GradientButton2
        ' 
        Guna2GradientButton2.Anchor = AnchorStyles.Top Or AnchorStyles.Left Or AnchorStyles.Right
        Guna2GradientButton2.CustomizableEdges = CustomizableEdges3
        Guna2GradientButton2.DisabledState.BorderColor = Color.DarkGray
        Guna2GradientButton2.DisabledState.CustomBorderColor = Color.DarkGray
        Guna2GradientButton2.DisabledState.FillColor = Color.FromArgb(CByte(169), CByte(169), CByte(169))
        Guna2GradientButton2.DisabledState.FillColor2 = Color.FromArgb(CByte(169), CByte(169), CByte(169))
        Guna2GradientButton2.DisabledState.ForeColor = Color.FromArgb(CByte(141), CByte(141), CByte(141))
        Guna2GradientButton2.FillColor = Color.Black
        Guna2GradientButton2.FillColor2 = Color.Black
        Guna2GradientButton2.Font = New Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point)
        Guna2GradientButton2.ForeColor = Color.White
        Guna2GradientButton2.Location = New Point(188, 43)
        Guna2GradientButton2.Name = "Guna2GradientButton2"
        Guna2GradientButton2.ShadowDecoration.CustomizableEdges = CustomizableEdges4
        Guna2GradientButton2.Size = New Size(213, 10)
        Guna2GradientButton2.TabIndex = 4
        ' 
        ' Guna2GradientButton1
        ' 
        Guna2GradientButton1.Anchor = AnchorStyles.Top Or AnchorStyles.Left Or AnchorStyles.Right
        Guna2GradientButton1.CustomizableEdges = CustomizableEdges5
        Guna2GradientButton1.DisabledState.BorderColor = Color.DarkGray
        Guna2GradientButton1.DisabledState.CustomBorderColor = Color.DarkGray
        Guna2GradientButton1.DisabledState.FillColor = Color.FromArgb(CByte(169), CByte(169), CByte(169))
        Guna2GradientButton1.DisabledState.FillColor2 = Color.FromArgb(CByte(169), CByte(169), CByte(169))
        Guna2GradientButton1.DisabledState.ForeColor = Color.FromArgb(CByte(141), CByte(141), CByte(141))
        Guna2GradientButton1.FillColor = Color.FromArgb(CByte(255), CByte(128), CByte(0))
        Guna2GradientButton1.FillColor2 = Color.Black
        Guna2GradientButton1.Font = New Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point)
        Guna2GradientButton1.ForeColor = Color.White
        Guna2GradientButton1.Location = New Point(188, 12)
        Guna2GradientButton1.Name = "Guna2GradientButton1"
        Guna2GradientButton1.ShadowDecoration.CustomizableEdges = CustomizableEdges6
        Guna2GradientButton1.Size = New Size(300, 10)
        Guna2GradientButton1.TabIndex = 3
        ' 
        ' PictureBox1
        ' 
        PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), Image)
        PictureBox1.Location = New Point(12, 7)
        PictureBox1.Name = "PictureBox1"
        PictureBox1.Size = New Size(150, 75)
        PictureBox1.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox1.TabIndex = 2
        PictureBox1.TabStop = False
        ' 
        ' TableLayoutPanel1
        ' 
        TableLayoutPanel1.Anchor = AnchorStyles.Top Or AnchorStyles.Right
        TableLayoutPanel1.ColumnCount = 5
        TableLayoutPanel1.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 20F))
        TableLayoutPanel1.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 20F))
        TableLayoutPanel1.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 20F))
        TableLayoutPanel1.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 20F))
        TableLayoutPanel1.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 20F))
        TableLayoutPanel1.Controls.Add(btnLogout, 4, 0)
        TableLayoutPanel1.Controls.Add(btnLaporan, 3, 0)
        TableLayoutPanel1.Controls.Add(btnKelolaStok, 1, 0)
        TableLayoutPanel1.Controls.Add(btnKelolaProduk, 0, 0)
        TableLayoutPanel1.Controls.Add(btnKelolaUsers, 2, 0)
        TableLayoutPanel1.Location = New Point(527, 3)
        TableLayoutPanel1.Name = "TableLayoutPanel1"
        TableLayoutPanel1.RowCount = 1
        TableLayoutPanel1.RowStyles.Add(New RowStyle(SizeType.Percent, 100F))
        TableLayoutPanel1.Size = New Size(664, 79)
        TableLayoutPanel1.TabIndex = 1
        ' 
        ' btnLogout
        ' 
        btnLogout.CustomizableEdges = CustomizableEdges7
        btnLogout.DisabledState.BorderColor = Color.DarkGray
        btnLogout.DisabledState.CustomBorderColor = Color.DarkGray
        btnLogout.DisabledState.FillColor = Color.FromArgb(CByte(169), CByte(169), CByte(169))
        btnLogout.DisabledState.FillColor2 = Color.FromArgb(CByte(169), CByte(169), CByte(169))
        btnLogout.DisabledState.ForeColor = Color.FromArgb(CByte(141), CByte(141), CByte(141))
        btnLogout.FillColor = Color.Orange
        btnLogout.FillColor2 = Color.Black
        btnLogout.Font = New Font("Arial", 9F, FontStyle.Bold, GraphicsUnit.Point)
        btnLogout.ForeColor = Color.White
        btnLogout.Location = New Point(531, 3)
        btnLogout.Name = "btnLogout"
        btnLogout.ShadowDecoration.CustomizableEdges = CustomizableEdges8
        btnLogout.Size = New Size(126, 73)
        btnLogout.TabIndex = 5
        btnLogout.Text = "Logout"
        ' 
        ' btnLaporan
        ' 
        btnLaporan.CustomizableEdges = CustomizableEdges9
        btnLaporan.DisabledState.BorderColor = Color.DarkGray
        btnLaporan.DisabledState.CustomBorderColor = Color.DarkGray
        btnLaporan.DisabledState.FillColor = Color.FromArgb(CByte(169), CByte(169), CByte(169))
        btnLaporan.DisabledState.FillColor2 = Color.FromArgb(CByte(169), CByte(169), CByte(169))
        btnLaporan.DisabledState.ForeColor = Color.FromArgb(CByte(141), CByte(141), CByte(141))
        btnLaporan.FillColor = Color.Black
        btnLaporan.FillColor2 = Color.Orange
        btnLaporan.Font = New Font("Arial", 9F, FontStyle.Bold, GraphicsUnit.Point)
        btnLaporan.ForeColor = Color.White
        btnLaporan.Location = New Point(399, 3)
        btnLaporan.Name = "btnLaporan"
        btnLaporan.ShadowDecoration.CustomizableEdges = CustomizableEdges10
        btnLaporan.Size = New Size(126, 73)
        btnLaporan.TabIndex = 4
        btnLaporan.Text = "Laporan"
        ' 
        ' btnKelolaStok
        ' 
        btnKelolaStok.CustomizableEdges = CustomizableEdges11
        btnKelolaStok.DisabledState.BorderColor = Color.DarkGray
        btnKelolaStok.DisabledState.CustomBorderColor = Color.DarkGray
        btnKelolaStok.DisabledState.FillColor = Color.FromArgb(CByte(169), CByte(169), CByte(169))
        btnKelolaStok.DisabledState.FillColor2 = Color.FromArgb(CByte(169), CByte(169), CByte(169))
        btnKelolaStok.DisabledState.ForeColor = Color.FromArgb(CByte(141), CByte(141), CByte(141))
        btnKelolaStok.FillColor = Color.Black
        btnKelolaStok.FillColor2 = Color.Orange
        btnKelolaStok.Font = New Font("Arial", 9F, FontStyle.Bold, GraphicsUnit.Point)
        btnKelolaStok.ForeColor = Color.White
        btnKelolaStok.Location = New Point(135, 3)
        btnKelolaStok.Name = "btnKelolaStok"
        btnKelolaStok.ShadowDecoration.CustomizableEdges = CustomizableEdges12
        btnKelolaStok.Size = New Size(126, 73)
        btnKelolaStok.TabIndex = 2
        btnKelolaStok.Text = "Kelola Stok "
        ' 
        ' btnKelolaProduk
        ' 
        btnKelolaProduk.CustomizableEdges = CustomizableEdges13
        btnKelolaProduk.DisabledState.BorderColor = Color.DarkGray
        btnKelolaProduk.DisabledState.CustomBorderColor = Color.DarkGray
        btnKelolaProduk.DisabledState.FillColor = Color.FromArgb(CByte(169), CByte(169), CByte(169))
        btnKelolaProduk.DisabledState.FillColor2 = Color.FromArgb(CByte(169), CByte(169), CByte(169))
        btnKelolaProduk.DisabledState.ForeColor = Color.FromArgb(CByte(141), CByte(141), CByte(141))
        btnKelolaProduk.FillColor = Color.Orange
        btnKelolaProduk.FillColor2 = Color.Black
        btnKelolaProduk.Font = New Font("Arial", 9F, FontStyle.Bold, GraphicsUnit.Point)
        btnKelolaProduk.ForeColor = Color.White
        btnKelolaProduk.Location = New Point(3, 3)
        btnKelolaProduk.Name = "btnKelolaProduk"
        btnKelolaProduk.ShadowDecoration.CustomizableEdges = CustomizableEdges14
        btnKelolaProduk.Size = New Size(126, 73)
        btnKelolaProduk.TabIndex = 1
        btnKelolaProduk.Text = "Kelola Produk"
        ' 
        ' btnKelolaUsers
        ' 
        btnKelolaUsers.CustomizableEdges = CustomizableEdges15
        btnKelolaUsers.DisabledState.BorderColor = Color.DarkGray
        btnKelolaUsers.DisabledState.CustomBorderColor = Color.DarkGray
        btnKelolaUsers.DisabledState.FillColor = Color.FromArgb(CByte(169), CByte(169), CByte(169))
        btnKelolaUsers.DisabledState.FillColor2 = Color.FromArgb(CByte(169), CByte(169), CByte(169))
        btnKelolaUsers.DisabledState.ForeColor = Color.FromArgb(CByte(141), CByte(141), CByte(141))
        btnKelolaUsers.FillColor = Color.Orange
        btnKelolaUsers.FillColor2 = Color.Black
        btnKelolaUsers.Font = New Font("Arial", 9F, FontStyle.Bold, GraphicsUnit.Point)
        btnKelolaUsers.ForeColor = Color.White
        btnKelolaUsers.Location = New Point(267, 3)
        btnKelolaUsers.Name = "btnKelolaUsers"
        btnKelolaUsers.ShadowDecoration.CustomizableEdges = CustomizableEdges16
        btnKelolaUsers.Size = New Size(126, 73)
        btnKelolaUsers.TabIndex = 3
        btnKelolaUsers.Text = "Kelola Users"
        ' 
        ' Panel2
        ' 
        Panel2.Dock = DockStyle.Bottom
        Panel2.Location = New Point(0, 594)
        Panel2.Name = "Panel2"
        Panel2.Size = New Size(1191, 44)
        Panel2.TabIndex = 1
        ' 
        ' TableLayoutPanel3
        ' 
        TableLayoutPanel3.ColumnCount = 5
        TableLayoutPanel3.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 20F))
        TableLayoutPanel3.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 20F))
        TableLayoutPanel3.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 20F))
        TableLayoutPanel3.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 20F))
        TableLayoutPanel3.ColumnStyles.Add(New ColumnStyle(SizeType.Absolute, 20F))
        TableLayoutPanel3.Dock = DockStyle.Top
        TableLayoutPanel3.Location = New Point(0, 0)
        TableLayoutPanel3.Name = "TableLayoutPanel3"
        TableLayoutPanel3.RowCount = 1
        TableLayoutPanel3.RowStyles.Add(New RowStyle(SizeType.Absolute, 20F))
        TableLayoutPanel3.Size = New Size(200, 100)
        TableLayoutPanel3.TabIndex = 0
        ' 
        ' TableLayoutPanel4
        ' 
        TableLayoutPanel4.ColumnCount = 5
        TableLayoutPanel4.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 20F))
        TableLayoutPanel4.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 20F))
        TableLayoutPanel4.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 20F))
        TableLayoutPanel4.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 20F))
        TableLayoutPanel4.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 20F))
        TableLayoutPanel4.Controls.Add(Panel10, 3, 0)
        TableLayoutPanel4.Location = New Point(0, 0)
        TableLayoutPanel4.Name = "TableLayoutPanel4"
        TableLayoutPanel4.RowCount = 1
        TableLayoutPanel4.RowStyles.Add(New RowStyle(SizeType.Absolute, 20F))
        TableLayoutPanel4.Size = New Size(200, 100)
        TableLayoutPanel4.TabIndex = 0
        ' 
        ' Panel10
        ' 
        Panel10.Controls.Add(Label7)
        Panel10.Controls.Add(Label8)
        Panel10.Location = New Point(123, 3)
        Panel10.Name = "Panel10"
        Panel10.Size = New Size(34, 94)
        Panel10.TabIndex = 2
        ' 
        ' Label7
        ' 
        Label7.AutoSize = True
        Label7.Font = New Font("Arial", 11F, FontStyle.Bold, GraphicsUnit.Point)
        Label7.Location = New Point(19, 98)
        Label7.Name = "Label7"
        Label7.Size = New Size(189, 26)
        Label7.TabIndex = 1
        Label7.Text = "Penjualan Hari Ini"
        ' 
        ' Label8
        ' 
        Label8.AutoSize = True
        Label8.Font = New Font("Arial", 20F, FontStyle.Bold, GraphicsUnit.Point)
        Label8.Location = New Point(19, 14)
        Label8.Name = "Label8"
        Label8.Size = New Size(97, 46)
        Label8.TabIndex = 0
        Label8.Text = "0.00"
        ' 
        ' Panel11
        ' 
        Panel11.Controls.Add(Label9)
        Panel11.Controls.Add(Label10)
        Panel11.Location = New Point(83, 3)
        Panel11.Name = "Panel11"
        Panel11.Size = New Size(34, 136)
        Panel11.TabIndex = 2
        ' 
        ' Label9
        ' 
        Label9.AutoSize = True
        Label9.Font = New Font("Arial", 11F, FontStyle.Bold, GraphicsUnit.Point)
        Label9.Location = New Point(19, 98)
        Label9.Name = "Label9"
        Label9.Size = New Size(189, 26)
        Label9.TabIndex = 1
        Label9.Text = "Penjualan Hari Ini"
        ' 
        ' Label10
        ' 
        Label10.AutoSize = True
        Label10.Font = New Font("Arial", 20F, FontStyle.Bold, GraphicsUnit.Point)
        Label10.Location = New Point(19, 14)
        Label10.Name = "Label10"
        Label10.Size = New Size(97, 46)
        Label10.TabIndex = 0
        Label10.Text = "0.00"
        ' 
        ' Panel3
        ' 
        Panel3.Anchor = AnchorStyles.Left Or AnchorStyles.Right
        Panel3.Controls.Add(TableLayoutPanel5)
        Panel3.Controls.Add(Panel5)
        Panel3.Controls.Add(TableLayoutPanel2)
        Panel3.Controls.Add(Panel4)
        Panel3.Location = New Point(0, 90)
        Panel3.Name = "Panel3"
        Panel3.Size = New Size(1191, 504)
        Panel3.TabIndex = 2
        ' 
        ' TableLayoutPanel5
        ' 
        TableLayoutPanel5.ColumnCount = 5
        TableLayoutPanel5.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 20F))
        TableLayoutPanel5.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 20F))
        TableLayoutPanel5.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 20F))
        TableLayoutPanel5.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 20F))
        TableLayoutPanel5.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 20F))
        TableLayoutPanel5.Controls.Add(DataGridView1, 0, 0)
        TableLayoutPanel5.Controls.Add(Panel12, 2, 0)
        TableLayoutPanel5.Controls.Add(Panel9, 1, 0)
        TableLayoutPanel5.Dock = DockStyle.Top
        TableLayoutPanel5.Location = New Point(0, 234)
        TableLayoutPanel5.Margin = New Padding(5)
        TableLayoutPanel5.Name = "TableLayoutPanel5"
        TableLayoutPanel5.RowCount = 1
        TableLayoutPanel5.RowStyles.Add(New RowStyle(SizeType.Percent, 100F))
        TableLayoutPanel5.Size = New Size(1191, 150)
        TableLayoutPanel5.TabIndex = 3
        ' 
        ' DataGridView1
        ' 
        DataGridView1.AllowUserToAddRows = False
        DataGridView1.AllowUserToDeleteRows = False
        DataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridView1.Columns.AddRange(New DataGridViewColumn() {Column1, Column2, Column3, Column4})
        DataGridView1.Location = New Point(3, 3)
        DataGridView1.Name = "DataGridView1"
        DataGridView1.ReadOnly = True
        DataGridView1.RowHeadersWidth = 62
        DataGridView1.RowTemplate.Height = 33
        DataGridView1.Size = New Size(232, 144)
        DataGridView1.TabIndex = 4
        DataGridView1.Visible = False
        ' 
        ' Column1
        ' 
        Column1.HeaderText = "notagihan"
        Column1.MinimumWidth = 8
        Column1.Name = "Column1"
        Column1.ReadOnly = True
        Column1.Visible = False
        Column1.Width = 150
        ' 
        ' Column2
        ' 
        Column2.HeaderText = "tanggaltagihan"
        Column2.MinimumWidth = 8
        Column2.Name = "Column2"
        Column2.ReadOnly = True
        Column2.Width = 150
        ' 
        ' Column3
        ' 
        Column3.HeaderText = "bulan"
        Column3.MinimumWidth = 8
        Column3.Name = "Column3"
        Column3.ReadOnly = True
        Column3.Width = 150
        ' 
        ' Column4
        ' 
        Column4.HeaderText = "totalkeseluruhan"
        Column4.MinimumWidth = 8
        Column4.Name = "Column4"
        Column4.ReadOnly = True
        Column4.Width = 150
        ' 
        ' Panel12
        ' 
        Panel12.BorderStyle = BorderStyle.FixedSingle
        Panel12.Controls.Add(Guna2GradientButton8)
        Panel12.Controls.Add(Label13)
        Panel12.Controls.Add(LabelJumlahBulan)
        Panel12.Dock = DockStyle.Fill
        Panel12.Location = New Point(479, 3)
        Panel12.Name = "Panel12"
        Panel12.Size = New Size(232, 144)
        Panel12.TabIndex = 2
        ' 
        ' Guna2GradientButton8
        ' 
        Guna2GradientButton8.CustomizableEdges = CustomizableEdges17
        Guna2GradientButton8.DisabledState.BorderColor = Color.DarkGray
        Guna2GradientButton8.DisabledState.CustomBorderColor = Color.DarkGray
        Guna2GradientButton8.DisabledState.FillColor = Color.FromArgb(CByte(169), CByte(169), CByte(169))
        Guna2GradientButton8.DisabledState.FillColor2 = Color.FromArgb(CByte(169), CByte(169), CByte(169))
        Guna2GradientButton8.DisabledState.ForeColor = Color.FromArgb(CByte(141), CByte(141), CByte(141))
        Guna2GradientButton8.Dock = DockStyle.Left
        Guna2GradientButton8.FillColor = Color.Orange
        Guna2GradientButton8.FillColor2 = Color.Black
        Guna2GradientButton8.Font = New Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point)
        Guna2GradientButton8.ForeColor = Color.White
        Guna2GradientButton8.Location = New Point(0, 0)
        Guna2GradientButton8.Name = "Guna2GradientButton8"
        Guna2GradientButton8.ShadowDecoration.CustomizableEdges = CustomizableEdges18
        Guna2GradientButton8.Size = New Size(8, 142)
        Guna2GradientButton8.TabIndex = 3
        ' 
        ' Label13
        ' 
        Label13.AutoSize = True
        Label13.Font = New Font("Arial", 10F, FontStyle.Bold, GraphicsUnit.Point)
        Label13.Location = New Point(14, 81)
        Label13.Name = "Label13"
        Label13.Size = New Size(176, 48)
        Label13.TabIndex = 1
        Label13.Text = "Jumlah Penjualan" & vbCrLf & "Bulan Ini"
        ' 
        ' LabelJumlahBulan
        ' 
        LabelJumlahBulan.AutoSize = True
        LabelJumlahBulan.Font = New Font("Arial", 20F, FontStyle.Bold, GraphicsUnit.Point)
        LabelJumlahBulan.Location = New Point(14, 25)
        LabelJumlahBulan.Name = "LabelJumlahBulan"
        LabelJumlahBulan.Size = New Size(97, 46)
        LabelJumlahBulan.TabIndex = 0
        LabelJumlahBulan.Text = "0.00"
        ' 
        ' Panel9
        ' 
        Panel9.BorderStyle = BorderStyle.FixedSingle
        Panel9.Controls.Add(Guna2GradientButton9)
        Panel9.Controls.Add(Label11)
        Panel9.Controls.Add(LabelJumlahHari)
        Panel9.Dock = DockStyle.Fill
        Panel9.Location = New Point(241, 3)
        Panel9.Name = "Panel9"
        Panel9.Size = New Size(232, 144)
        Panel9.TabIndex = 1
        ' 
        ' Guna2GradientButton9
        ' 
        Guna2GradientButton9.CustomizableEdges = CustomizableEdges19
        Guna2GradientButton9.DisabledState.BorderColor = Color.DarkGray
        Guna2GradientButton9.DisabledState.CustomBorderColor = Color.DarkGray
        Guna2GradientButton9.DisabledState.FillColor = Color.FromArgb(CByte(169), CByte(169), CByte(169))
        Guna2GradientButton9.DisabledState.FillColor2 = Color.FromArgb(CByte(169), CByte(169), CByte(169))
        Guna2GradientButton9.DisabledState.ForeColor = Color.FromArgb(CByte(141), CByte(141), CByte(141))
        Guna2GradientButton9.Dock = DockStyle.Left
        Guna2GradientButton9.FillColor = Color.Orange
        Guna2GradientButton9.FillColor2 = Color.Black
        Guna2GradientButton9.Font = New Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point)
        Guna2GradientButton9.ForeColor = Color.White
        Guna2GradientButton9.Location = New Point(0, 0)
        Guna2GradientButton9.Name = "Guna2GradientButton9"
        Guna2GradientButton9.ShadowDecoration.CustomizableEdges = CustomizableEdges20
        Guna2GradientButton9.Size = New Size(8, 142)
        Guna2GradientButton9.TabIndex = 3
        ' 
        ' Label11
        ' 
        Label11.AutoSize = True
        Label11.Font = New Font("Arial", 10F, FontStyle.Bold, GraphicsUnit.Point)
        Label11.Location = New Point(14, 81)
        Label11.Name = "Label11"
        Label11.Size = New Size(182, 48)
        Label11.TabIndex = 1
        Label11.Text = "Jumlah Penjualan " & vbCrLf & "Hari Ini"
        ' 
        ' LabelJumlahHari
        ' 
        LabelJumlahHari.AutoSize = True
        LabelJumlahHari.Font = New Font("Arial", 20F, FontStyle.Bold, GraphicsUnit.Point)
        LabelJumlahHari.Location = New Point(14, 25)
        LabelJumlahHari.Name = "LabelJumlahHari"
        LabelJumlahHari.Size = New Size(97, 46)
        LabelJumlahHari.TabIndex = 0
        LabelJumlahHari.Text = "0.00"
        ' 
        ' Panel5
        ' 
        Panel5.Dock = DockStyle.Top
        Panel5.Location = New Point(0, 194)
        Panel5.Name = "Panel5"
        Panel5.Size = New Size(1191, 40)
        Panel5.TabIndex = 2
        ' 
        ' TableLayoutPanel2
        ' 
        TableLayoutPanel2.ColumnCount = 5
        TableLayoutPanel2.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 20F))
        TableLayoutPanel2.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 20F))
        TableLayoutPanel2.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 20F))
        TableLayoutPanel2.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 20F))
        TableLayoutPanel2.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 20F))
        TableLayoutPanel2.Controls.Add(Panel7, 2, 0)
        TableLayoutPanel2.Controls.Add(Panel8, 3, 0)
        TableLayoutPanel2.Controls.Add(Panel6, 1, 0)
        TableLayoutPanel2.Dock = DockStyle.Top
        TableLayoutPanel2.Location = New Point(0, 44)
        TableLayoutPanel2.Margin = New Padding(5)
        TableLayoutPanel2.Name = "TableLayoutPanel2"
        TableLayoutPanel2.RowCount = 1
        TableLayoutPanel2.RowStyles.Add(New RowStyle(SizeType.Percent, 100F))
        TableLayoutPanel2.Size = New Size(1191, 150)
        TableLayoutPanel2.TabIndex = 1
        ' 
        ' Panel7
        ' 
        Panel7.BorderStyle = BorderStyle.FixedSingle
        Panel7.Controls.Add(Guna2GradientButton5)
        Panel7.Controls.Add(Label3)
        Panel7.Controls.Add(LabelBulanIni)
        Panel7.Dock = DockStyle.Fill
        Panel7.Location = New Point(479, 3)
        Panel7.Name = "Panel7"
        Panel7.Size = New Size(232, 144)
        Panel7.TabIndex = 1
        ' 
        ' Guna2GradientButton5
        ' 
        Guna2GradientButton5.CustomizableEdges = CustomizableEdges21
        Guna2GradientButton5.DisabledState.BorderColor = Color.DarkGray
        Guna2GradientButton5.DisabledState.CustomBorderColor = Color.DarkGray
        Guna2GradientButton5.DisabledState.FillColor = Color.FromArgb(CByte(169), CByte(169), CByte(169))
        Guna2GradientButton5.DisabledState.FillColor2 = Color.FromArgb(CByte(169), CByte(169), CByte(169))
        Guna2GradientButton5.DisabledState.ForeColor = Color.FromArgb(CByte(141), CByte(141), CByte(141))
        Guna2GradientButton5.Dock = DockStyle.Left
        Guna2GradientButton5.FillColor = Color.Orange
        Guna2GradientButton5.FillColor2 = Color.Black
        Guna2GradientButton5.Font = New Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point)
        Guna2GradientButton5.ForeColor = Color.White
        Guna2GradientButton5.Location = New Point(0, 0)
        Guna2GradientButton5.Name = "Guna2GradientButton5"
        Guna2GradientButton5.ShadowDecoration.CustomizableEdges = CustomizableEdges22
        Guna2GradientButton5.Size = New Size(8, 142)
        Guna2GradientButton5.TabIndex = 3
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Font = New Font("Arial", 10F, FontStyle.Bold, GraphicsUnit.Point)
        Label3.Location = New Point(14, 83)
        Label3.Name = "Label3"
        Label3.Size = New Size(190, 24)
        Label3.TabIndex = 1
        Label3.Text = "Penjualan Bulan Ini"
        ' 
        ' LabelBulanIni
        ' 
        LabelBulanIni.AutoSize = True
        LabelBulanIni.Font = New Font("Arial", 20F, FontStyle.Bold, GraphicsUnit.Point)
        LabelBulanIni.Location = New Point(14, 25)
        LabelBulanIni.Name = "LabelBulanIni"
        LabelBulanIni.Size = New Size(97, 46)
        LabelBulanIni.TabIndex = 0
        LabelBulanIni.Text = "0.00"
        ' 
        ' Panel8
        ' 
        Panel8.BorderStyle = BorderStyle.FixedSingle
        Panel8.Controls.Add(Guna2GradientButton6)
        Panel8.Controls.Add(Label5)
        Panel8.Controls.Add(LabelJumlahTransaksi)
        Panel8.Dock = DockStyle.Fill
        Panel8.Location = New Point(717, 3)
        Panel8.Name = "Panel8"
        Panel8.Size = New Size(232, 144)
        Panel8.TabIndex = 2
        ' 
        ' Guna2GradientButton6
        ' 
        Guna2GradientButton6.CustomizableEdges = CustomizableEdges23
        Guna2GradientButton6.DisabledState.BorderColor = Color.DarkGray
        Guna2GradientButton6.DisabledState.CustomBorderColor = Color.DarkGray
        Guna2GradientButton6.DisabledState.FillColor = Color.FromArgb(CByte(169), CByte(169), CByte(169))
        Guna2GradientButton6.DisabledState.FillColor2 = Color.FromArgb(CByte(169), CByte(169), CByte(169))
        Guna2GradientButton6.DisabledState.ForeColor = Color.FromArgb(CByte(141), CByte(141), CByte(141))
        Guna2GradientButton6.Dock = DockStyle.Left
        Guna2GradientButton6.FillColor = Color.Orange
        Guna2GradientButton6.FillColor2 = Color.Black
        Guna2GradientButton6.Font = New Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point)
        Guna2GradientButton6.ForeColor = Color.White
        Guna2GradientButton6.Location = New Point(0, 0)
        Guna2GradientButton6.Name = "Guna2GradientButton6"
        Guna2GradientButton6.ShadowDecoration.CustomizableEdges = CustomizableEdges24
        Guna2GradientButton6.Size = New Size(8, 142)
        Guna2GradientButton6.TabIndex = 3
        ' 
        ' Label5
        ' 
        Label5.AutoSize = True
        Label5.Font = New Font("Arial", 11F, FontStyle.Bold, GraphicsUnit.Point)
        Label5.Location = New Point(14, 81)
        Label5.Name = "Label5"
        Label5.Size = New Size(192, 26)
        Label5.TabIndex = 1
        Label5.Text = "Jumlah Transaksi"
        ' 
        ' LabelJumlahTransaksi
        ' 
        LabelJumlahTransaksi.AutoSize = True
        LabelJumlahTransaksi.Font = New Font("Arial", 20F, FontStyle.Bold, GraphicsUnit.Point)
        LabelJumlahTransaksi.Location = New Point(14, 25)
        LabelJumlahTransaksi.Name = "LabelJumlahTransaksi"
        LabelJumlahTransaksi.Size = New Size(97, 46)
        LabelJumlahTransaksi.TabIndex = 0
        LabelJumlahTransaksi.Text = "0.00"
        ' 
        ' Panel6
        ' 
        Panel6.BorderStyle = BorderStyle.FixedSingle
        Panel6.Controls.Add(Guna2GradientButton4)
        Panel6.Controls.Add(Label2)
        Panel6.Controls.Add(LabelHariIni)
        Panel6.Dock = DockStyle.Fill
        Panel6.Location = New Point(241, 3)
        Panel6.Name = "Panel6"
        Panel6.Size = New Size(232, 144)
        Panel6.TabIndex = 0
        ' 
        ' Guna2GradientButton4
        ' 
        Guna2GradientButton4.CustomizableEdges = CustomizableEdges25
        Guna2GradientButton4.DisabledState.BorderColor = Color.DarkGray
        Guna2GradientButton4.DisabledState.CustomBorderColor = Color.DarkGray
        Guna2GradientButton4.DisabledState.FillColor = Color.FromArgb(CByte(169), CByte(169), CByte(169))
        Guna2GradientButton4.DisabledState.FillColor2 = Color.FromArgb(CByte(169), CByte(169), CByte(169))
        Guna2GradientButton4.DisabledState.ForeColor = Color.FromArgb(CByte(141), CByte(141), CByte(141))
        Guna2GradientButton4.Dock = DockStyle.Left
        Guna2GradientButton4.FillColor = Color.Orange
        Guna2GradientButton4.FillColor2 = Color.Black
        Guna2GradientButton4.Font = New Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point)
        Guna2GradientButton4.ForeColor = Color.White
        Guna2GradientButton4.Location = New Point(0, 0)
        Guna2GradientButton4.Name = "Guna2GradientButton4"
        Guna2GradientButton4.ShadowDecoration.CustomizableEdges = CustomizableEdges26
        Guna2GradientButton4.Size = New Size(8, 142)
        Guna2GradientButton4.TabIndex = 2
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Font = New Font("Arial", 10F, FontStyle.Bold, GraphicsUnit.Point)
        Label2.Location = New Point(14, 83)
        Label2.Name = "Label2"
        Label2.Size = New Size(174, 24)
        Label2.TabIndex = 1
        Label2.Text = "Penjualan Hari Ini"
        ' 
        ' LabelHariIni
        ' 
        LabelHariIni.AutoSize = True
        LabelHariIni.Font = New Font("Arial", 20F, FontStyle.Bold, GraphicsUnit.Point)
        LabelHariIni.Location = New Point(14, 25)
        LabelHariIni.Name = "LabelHariIni"
        LabelHariIni.Size = New Size(97, 46)
        LabelHariIni.TabIndex = 0
        LabelHariIni.Text = "0.00"
        ' 
        ' Panel4
        ' 
        Panel4.Dock = DockStyle.Top
        Panel4.Location = New Point(0, 0)
        Panel4.Name = "Panel4"
        Panel4.Size = New Size(1191, 44)
        Panel4.TabIndex = 0
        ' 
        ' FormAdmin
        ' 
        AutoScaleDimensions = New SizeF(10F, 25F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(1191, 638)
        Controls.Add(Panel3)
        Controls.Add(Panel2)
        Controls.Add(Panel1)
        Icon = CType(resources.GetObject("$this.Icon"), Icon)
        Name = "FormAdmin"
        StartPosition = FormStartPosition.CenterScreen
        Text = "FormAdmin"
        WindowState = FormWindowState.Maximized
        Panel1.ResumeLayout(False)
        CType(PictureBox1, ComponentModel.ISupportInitialize).EndInit()
        TableLayoutPanel1.ResumeLayout(False)
        TableLayoutPanel4.ResumeLayout(False)
        Panel10.ResumeLayout(False)
        Panel10.PerformLayout()
        Panel11.ResumeLayout(False)
        Panel11.PerformLayout()
        Panel3.ResumeLayout(False)
        TableLayoutPanel5.ResumeLayout(False)
        CType(DataGridView1, ComponentModel.ISupportInitialize).EndInit()
        Panel12.ResumeLayout(False)
        Panel12.PerformLayout()
        Panel9.ResumeLayout(False)
        Panel9.PerformLayout()
        TableLayoutPanel2.ResumeLayout(False)
        Panel7.ResumeLayout(False)
        Panel7.PerformLayout()
        Panel8.ResumeLayout(False)
        Panel8.PerformLayout()
        Panel6.ResumeLayout(False)
        Panel6.PerformLayout()
        ResumeLayout(False)
    End Sub

    Friend WithEvents Panel1 As Panel
    Friend WithEvents TableLayoutPanel1 As TableLayoutPanel
    Friend WithEvents btnKelolaProduk As Guna.UI2.WinForms.Guna2GradientButton
    Friend WithEvents btnLogout As Guna.UI2.WinForms.Guna2GradientButton
    Friend WithEvents btnLaporan As Guna.UI2.WinForms.Guna2GradientButton
    Friend WithEvents btnKelolaStok As Guna.UI2.WinForms.Guna2GradientButton
    Friend WithEvents btnKelolaUsers As Guna.UI2.WinForms.Guna2GradientButton
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Guna2GradientButton3 As Guna.UI2.WinForms.Guna2GradientButton
    Friend WithEvents Guna2GradientButton2 As Guna.UI2.WinForms.Guna2GradientButton
    Friend WithEvents Guna2GradientButton1 As Guna.UI2.WinForms.Guna2GradientButton
    Friend WithEvents Panel2 As Panel
    Friend WithEvents TableLayoutPanel3 As TableLayoutPanel
    Friend WithEvents TableLayoutPanel4 As TableLayoutPanel
    Friend WithEvents Panel10 As Panel
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Panel11 As Panel
    Friend WithEvents Label9 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Panel3 As Panel
    Friend WithEvents TableLayoutPanel5 As TableLayoutPanel
    Friend WithEvents Panel12 As Panel
    Friend WithEvents Label13 As Label
    Friend WithEvents LabelJumlahBulan As Label
    Friend WithEvents Panel9 As Panel
    Friend WithEvents Label11 As Label
    Friend WithEvents LabelJumlahHari As Label
    Friend WithEvents Panel5 As Panel
    Friend WithEvents TableLayoutPanel2 As TableLayoutPanel
    Friend WithEvents Panel6 As Panel
    Friend WithEvents Label2 As Label
    Friend WithEvents LabelHariIni As Label
    Friend WithEvents Panel7 As Panel
    Friend WithEvents Label3 As Label
    Friend WithEvents LabelBulanIni As Label
    Friend WithEvents Panel8 As Panel
    Friend WithEvents Label5 As Label
    Friend WithEvents LabelJumlahTransaksi As Label
    Friend WithEvents Panel4 As Panel
    Friend WithEvents Guna2GradientButton4 As Guna.UI2.WinForms.Guna2GradientButton
    Friend WithEvents Guna2GradientButton8 As Guna.UI2.WinForms.Guna2GradientButton
    Friend WithEvents Guna2GradientButton9 As Guna.UI2.WinForms.Guna2GradientButton
    Friend WithEvents Guna2GradientButton5 As Guna.UI2.WinForms.Guna2GradientButton
    Friend WithEvents Guna2GradientButton6 As Guna.UI2.WinForms.Guna2GradientButton
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents Column1 As DataGridViewTextBoxColumn
    Friend WithEvents Column2 As DataGridViewTextBoxColumn
    Friend WithEvents Column3 As DataGridViewTextBoxColumn
    Friend WithEvents Column4 As DataGridViewTextBoxColumn
End Class
