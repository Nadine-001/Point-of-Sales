﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormKasir
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        components = New ComponentModel.Container()
        Dim CustomizableEdges1 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim resources As ComponentModel.ComponentResourceManager = New ComponentModel.ComponentResourceManager(GetType(FormKasir))
        Dim CustomizableEdges2 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim CustomizableEdges3 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim CustomizableEdges4 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim CustomizableEdges5 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim CustomizableEdges6 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim CustomizableEdges7 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim CustomizableEdges8 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim CustomizableEdges9 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim CustomizableEdges10 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim CustomizableEdges11 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim CustomizableEdges12 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim CustomizableEdges13 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim CustomizableEdges14 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim CustomizableEdges15 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim CustomizableEdges16 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim CustomizableEdges17 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim CustomizableEdges18 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim CustomizableEdges19 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim CustomizableEdges20 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim DataGridViewCellStyle1 As DataGridViewCellStyle = New DataGridViewCellStyle()
        Dim CustomizableEdges21 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim CustomizableEdges22 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim CustomizableEdges23 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim CustomizableEdges24 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim CustomizableEdges25 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim CustomizableEdges26 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim CustomizableEdges27 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim CustomizableEdges28 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Panel1 = New Panel()
        LabelWaktu = New Label()
        Guna2PictureBox1 = New Guna.UI2.WinForms.Guna2PictureBox()
        WaktuTanggal = New DateTimePicker()
        Panel2 = New Panel()
        LabelTanggal = New Label()
        Label5 = New Label()
        Text_CariProduk_Barcode = New Guna.UI2.WinForms.Guna2TextBox()
        textNoTagihan = New Guna.UI2.WinForms.Guna2TextBox()
        Label4 = New Label()
        Label3 = New Label()
        TableLayoutPanel1 = New TableLayoutPanel()
        ButtonLogout = New Guna.UI2.WinForms.Guna2Button()
        ButtonUbahPassword = New Guna.UI2.WinForms.Guna2Button()
        ButtonHapus = New Guna.UI2.WinForms.Guna2Button()
        ButtonLaporan = New Guna.UI2.WinForms.Guna2Button()
        ButtonDiskon = New Guna.UI2.WinForms.Guna2Button()
        ButtonBatal = New Guna.UI2.WinForms.Guna2Button()
        ButtonBaru = New Guna.UI2.WinForms.Guna2Button()
        DataGridView1 = New DataGridView()
        Column1 = New DataGridViewTextBoxColumn()
        Column2 = New DataGridViewTextBoxColumn()
        Column3 = New DataGridViewTextBoxColumn()
        Column4 = New DataGridViewTextBoxColumn()
        Column5 = New DataGridViewTextBoxColumn()
        Column6 = New DataGridViewTextBoxColumn()
        Column7 = New DataGridViewTextBoxColumn()
        Column8 = New DataGridViewTextBoxColumn()
        Column9 = New DataGridViewTextBoxColumn()
        Column10 = New DataGridViewTextBoxColumn()
        LabelHitungKeseluruhan = New Label()
        ButtonBayar = New Guna.UI2.WinForms.Guna2Button()
        Label7 = New Label()
        Label8 = New Label()
        Label9 = New Label()
        Label10 = New Label()
        Label11 = New Label()
        Label12 = New Label()
        Label13 = New Label()
        Label14 = New Label()
        LabelJumlahBarang = New Label()
        LabelTotalPajak = New Label()
        LabelTotalHarga = New Label()
        textDiskon = New Guna.UI2.WinForms.Guna2TextBox()
        LabelDiskon = New Label()
        LabelTotalKeseluruhan = New Label()
        LabelKembalian = New Label()
        ComboPembayaran = New Guna.UI2.WinForms.Guna2ComboBox()
        textJmlDiterima = New Guna.UI2.WinForms.Guna2TextBox()
        Panel3 = New Panel()
        LabelSubtotal = New Label()
        Label6 = New Label()
        Timer1 = New Timer(components)
        Timer2 = New Timer(components)
        Panel1.SuspendLayout()
        CType(Guna2PictureBox1, ComponentModel.ISupportInitialize).BeginInit()
        Panel2.SuspendLayout()
        TableLayoutPanel1.SuspendLayout()
        CType(DataGridView1, ComponentModel.ISupportInitialize).BeginInit()
        Panel3.SuspendLayout()
        SuspendLayout()
        ' 
        ' Panel1
        ' 
        Panel1.BackColor = Color.White
        Panel1.Controls.Add(LabelWaktu)
        Panel1.Controls.Add(Guna2PictureBox1)
        Panel1.Dock = DockStyle.Top
        Panel1.Location = New Point(0, 0)
        Panel1.Name = "Panel1"
        Panel1.Size = New Size(1260, 78)
        Panel1.TabIndex = 0
        ' 
        ' LabelWaktu
        ' 
        LabelWaktu.Anchor = AnchorStyles.Top Or AnchorStyles.Right
        LabelWaktu.Font = New Font("Arial", 16F, FontStyle.Bold, GraphicsUnit.Point)
        LabelWaktu.ForeColor = Color.FromArgb(CByte(255), CByte(128), CByte(0))
        LabelWaktu.Location = New Point(986, 14)
        LabelWaktu.Name = "LabelWaktu"
        LabelWaktu.Size = New Size(262, 49)
        LabelWaktu.TabIndex = 35
        LabelWaktu.Text = "00.00"
        LabelWaktu.TextAlign = ContentAlignment.TopRight
        ' 
        ' Guna2PictureBox1
        ' 
        Guna2PictureBox1.CustomizableEdges = CustomizableEdges1
        Guna2PictureBox1.Image = CType(resources.GetObject("Guna2PictureBox1.Image"), Image)
        Guna2PictureBox1.ImageRotate = 0F
        Guna2PictureBox1.Location = New Point(12, 12)
        Guna2PictureBox1.Name = "Guna2PictureBox1"
        Guna2PictureBox1.ShadowDecoration.CustomizableEdges = CustomizableEdges2
        Guna2PictureBox1.Size = New Size(126, 51)
        Guna2PictureBox1.SizeMode = PictureBoxSizeMode.StretchImage
        Guna2PictureBox1.TabIndex = 0
        Guna2PictureBox1.TabStop = False
        ' 
        ' WaktuTanggal
        ' 
        WaktuTanggal.Location = New Point(645, 26)
        WaktuTanggal.Name = "WaktuTanggal"
        WaktuTanggal.Size = New Size(300, 30)
        WaktuTanggal.TabIndex = 36
        ' 
        ' Panel2
        ' 
        Panel2.BackColor = Color.White
        Panel2.Controls.Add(WaktuTanggal)
        Panel2.Controls.Add(LabelTanggal)
        Panel2.Controls.Add(Label5)
        Panel2.Controls.Add(Text_CariProduk_Barcode)
        Panel2.Controls.Add(textNoTagihan)
        Panel2.Controls.Add(Label4)
        Panel2.Controls.Add(Label3)
        Panel2.Dock = DockStyle.Top
        Panel2.Location = New Point(0, 78)
        Panel2.Name = "Panel2"
        Panel2.Size = New Size(1260, 119)
        Panel2.TabIndex = 1
        ' 
        ' LabelTanggal
        ' 
        LabelTanggal.Anchor = AnchorStyles.Top Or AnchorStyles.Right
        LabelTanggal.Font = New Font("Arial", 11F, FontStyle.Bold, GraphicsUnit.Point)
        LabelTanggal.ForeColor = Color.FromArgb(CByte(255), CByte(128), CByte(0))
        LabelTanggal.Location = New Point(958, 12)
        LabelTanggal.Name = "LabelTanggal"
        LabelTanggal.Size = New Size(290, 63)
        LabelTanggal.TabIndex = 36
        LabelTanggal.Text = "00.00"
        LabelTanggal.TextAlign = ContentAlignment.TopRight
        ' 
        ' Label5
        ' 
        Label5.AutoSize = True
        Label5.Location = New Point(458, 32)
        Label5.Name = "Label5"
        Label5.Size = New Size(166, 24)
        Label5.TabIndex = 4
        Label5.Text = "Tanggal Tagihan"
        ' 
        ' Text_CariProduk_Barcode
        ' 
        Text_CariProduk_Barcode.CustomizableEdges = CustomizableEdges3
        Text_CariProduk_Barcode.DefaultText = ""
        Text_CariProduk_Barcode.DisabledState.BorderColor = Color.FromArgb(CByte(208), CByte(208), CByte(208))
        Text_CariProduk_Barcode.DisabledState.FillColor = Color.FromArgb(CByte(226), CByte(226), CByte(226))
        Text_CariProduk_Barcode.DisabledState.ForeColor = Color.FromArgb(CByte(138), CByte(138), CByte(138))
        Text_CariProduk_Barcode.DisabledState.PlaceholderForeColor = Color.FromArgb(CByte(138), CByte(138), CByte(138))
        Text_CariProduk_Barcode.FocusedState.BorderColor = Color.FromArgb(CByte(94), CByte(148), CByte(255))
        Text_CariProduk_Barcode.Font = New Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point)
        Text_CariProduk_Barcode.ForeColor = Color.Black
        Text_CariProduk_Barcode.HoverState.BorderColor = Color.FromArgb(CByte(94), CByte(148), CByte(255))
        Text_CariProduk_Barcode.Location = New Point(152, 72)
        Text_CariProduk_Barcode.Name = "Text_CariProduk_Barcode"
        Text_CariProduk_Barcode.PasswordChar = ChrW(0)
        Text_CariProduk_Barcode.PlaceholderText = ""
        Text_CariProduk_Barcode.SelectedText = ""
        Text_CariProduk_Barcode.ShadowDecoration.CustomizableEdges = CustomizableEdges4
        Text_CariProduk_Barcode.Size = New Size(793, 37)
        Text_CariProduk_Barcode.TabIndex = 3
        ' 
        ' textNoTagihan
        ' 
        textNoTagihan.CustomizableEdges = CustomizableEdges5
        textNoTagihan.DefaultText = ""
        textNoTagihan.DisabledState.BorderColor = Color.FromArgb(CByte(208), CByte(208), CByte(208))
        textNoTagihan.DisabledState.FillColor = Color.FromArgb(CByte(226), CByte(226), CByte(226))
        textNoTagihan.DisabledState.ForeColor = Color.FromArgb(CByte(138), CByte(138), CByte(138))
        textNoTagihan.DisabledState.PlaceholderForeColor = Color.FromArgb(CByte(138), CByte(138), CByte(138))
        textNoTagihan.FocusedState.BorderColor = Color.FromArgb(CByte(94), CByte(148), CByte(255))
        textNoTagihan.Font = New Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point)
        textNoTagihan.ForeColor = Color.Black
        textNoTagihan.HoverState.BorderColor = Color.FromArgb(CByte(94), CByte(148), CByte(255))
        textNoTagihan.Location = New Point(152, 19)
        textNoTagihan.Name = "textNoTagihan"
        textNoTagihan.PasswordChar = ChrW(0)
        textNoTagihan.PlaceholderText = ""
        textNoTagihan.SelectedText = ""
        textNoTagihan.ShadowDecoration.CustomizableEdges = CustomizableEdges6
        textNoTagihan.Size = New Size(300, 37)
        textNoTagihan.TabIndex = 2
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.Font = New Font("Arial", 9F, FontStyle.Bold, GraphicsUnit.Point)
        Label4.Location = New Point(12, 88)
        Label4.Name = "Label4"
        Label4.Size = New Size(72, 21)
        Label4.TabIndex = 1
        Label4.Text = "Produk"
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Font = New Font("Arial", 9F, FontStyle.Bold, GraphicsUnit.Point)
        Label3.Location = New Point(12, 35)
        Label3.Name = "Label3"
        Label3.Size = New Size(122, 21)
        Label3.TabIndex = 0
        Label3.Text = "Tagihan NO :"
        ' 
        ' TableLayoutPanel1
        ' 
        TableLayoutPanel1.BackColor = Color.White
        TableLayoutPanel1.ColumnCount = 7
        TableLayoutPanel1.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 14.2857141F))
        TableLayoutPanel1.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 14.2857141F))
        TableLayoutPanel1.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 14.2857141F))
        TableLayoutPanel1.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 14.2857141F))
        TableLayoutPanel1.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 14.2857141F))
        TableLayoutPanel1.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 14.2857141F))
        TableLayoutPanel1.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 14.2857141F))
        TableLayoutPanel1.Controls.Add(ButtonLogout, 6, 0)
        TableLayoutPanel1.Controls.Add(ButtonUbahPassword, 5, 0)
        TableLayoutPanel1.Controls.Add(ButtonHapus, 4, 0)
        TableLayoutPanel1.Controls.Add(ButtonLaporan, 3, 0)
        TableLayoutPanel1.Controls.Add(ButtonDiskon, 2, 0)
        TableLayoutPanel1.Controls.Add(ButtonBatal, 1, 0)
        TableLayoutPanel1.Controls.Add(ButtonBaru, 0, 0)
        TableLayoutPanel1.Dock = DockStyle.Bottom
        TableLayoutPanel1.Location = New Point(0, 671)
        TableLayoutPanel1.Name = "TableLayoutPanel1"
        TableLayoutPanel1.RowCount = 1
        TableLayoutPanel1.RowStyles.Add(New RowStyle(SizeType.Percent, 100F))
        TableLayoutPanel1.Size = New Size(1260, 60)
        TableLayoutPanel1.TabIndex = 2
        ' 
        ' ButtonLogout
        ' 
        ButtonLogout.CustomizableEdges = CustomizableEdges7
        ButtonLogout.DisabledState.BorderColor = Color.DarkGray
        ButtonLogout.DisabledState.CustomBorderColor = Color.DarkGray
        ButtonLogout.DisabledState.FillColor = Color.FromArgb(CByte(169), CByte(169), CByte(169))
        ButtonLogout.DisabledState.ForeColor = Color.FromArgb(CByte(141), CByte(141), CByte(141))
        ButtonLogout.FillColor = Color.OrangeRed
        ButtonLogout.Font = New Font("Arial", 9F, FontStyle.Bold, GraphicsUnit.Point)
        ButtonLogout.ForeColor = Color.White
        ButtonLogout.Location = New Point(1083, 3)
        ButtonLogout.Name = "ButtonLogout"
        ButtonLogout.ShadowDecoration.CustomizableEdges = CustomizableEdges8
        ButtonLogout.Size = New Size(174, 54)
        ButtonLogout.TabIndex = 12
        ButtonLogout.Text = "LOGOUT"
        ' 
        ' ButtonUbahPassword
        ' 
        ButtonUbahPassword.CustomizableEdges = CustomizableEdges9
        ButtonUbahPassword.DisabledState.BorderColor = Color.DarkGray
        ButtonUbahPassword.DisabledState.CustomBorderColor = Color.DarkGray
        ButtonUbahPassword.DisabledState.FillColor = Color.FromArgb(CByte(169), CByte(169), CByte(169))
        ButtonUbahPassword.DisabledState.ForeColor = Color.FromArgb(CByte(141), CByte(141), CByte(141))
        ButtonUbahPassword.Dock = DockStyle.Fill
        ButtonUbahPassword.FillColor = Color.FromArgb(CByte(255), CByte(128), CByte(0))
        ButtonUbahPassword.Font = New Font("Arial", 9F, FontStyle.Bold, GraphicsUnit.Point)
        ButtonUbahPassword.ForeColor = Color.White
        ButtonUbahPassword.Location = New Point(903, 3)
        ButtonUbahPassword.Name = "ButtonUbahPassword"
        ButtonUbahPassword.ShadowDecoration.CustomizableEdges = CustomizableEdges10
        ButtonUbahPassword.Size = New Size(174, 54)
        ButtonUbahPassword.TabIndex = 11
        ButtonUbahPassword.Text = "UBAH PASSWORD"
        ' 
        ' ButtonHapus
        ' 
        ButtonHapus.CustomizableEdges = CustomizableEdges11
        ButtonHapus.DisabledState.BorderColor = Color.DarkGray
        ButtonHapus.DisabledState.CustomBorderColor = Color.DarkGray
        ButtonHapus.DisabledState.FillColor = Color.FromArgb(CByte(169), CByte(169), CByte(169))
        ButtonHapus.DisabledState.ForeColor = Color.FromArgb(CByte(141), CByte(141), CByte(141))
        ButtonHapus.Dock = DockStyle.Fill
        ButtonHapus.FillColor = Color.FromArgb(CByte(255), CByte(128), CByte(0))
        ButtonHapus.Font = New Font("Arial", 9F, FontStyle.Bold, GraphicsUnit.Point)
        ButtonHapus.ForeColor = Color.White
        ButtonHapus.Location = New Point(723, 3)
        ButtonHapus.Name = "ButtonHapus"
        ButtonHapus.ShadowDecoration.CustomizableEdges = CustomizableEdges12
        ButtonHapus.Size = New Size(174, 54)
        ButtonHapus.TabIndex = 10
        ButtonHapus.Text = "HAPUS DARI DAFTAR"
        ' 
        ' ButtonLaporan
        ' 
        ButtonLaporan.CustomizableEdges = CustomizableEdges13
        ButtonLaporan.DisabledState.BorderColor = Color.DarkGray
        ButtonLaporan.DisabledState.CustomBorderColor = Color.DarkGray
        ButtonLaporan.DisabledState.FillColor = Color.FromArgb(CByte(169), CByte(169), CByte(169))
        ButtonLaporan.DisabledState.ForeColor = Color.FromArgb(CByte(141), CByte(141), CByte(141))
        ButtonLaporan.Dock = DockStyle.Fill
        ButtonLaporan.FillColor = Color.FromArgb(CByte(255), CByte(128), CByte(0))
        ButtonLaporan.Font = New Font("Arial", 9F, FontStyle.Bold, GraphicsUnit.Point)
        ButtonLaporan.ForeColor = Color.White
        ButtonLaporan.Location = New Point(543, 3)
        ButtonLaporan.Name = "ButtonLaporan"
        ButtonLaporan.ShadowDecoration.CustomizableEdges = CustomizableEdges14
        ButtonLaporan.Size = New Size(174, 54)
        ButtonLaporan.TabIndex = 9
        ButtonLaporan.Text = "LAPORAN"
        ' 
        ' ButtonDiskon
        ' 
        ButtonDiskon.CustomizableEdges = CustomizableEdges15
        ButtonDiskon.DisabledState.BorderColor = Color.DarkGray
        ButtonDiskon.DisabledState.CustomBorderColor = Color.DarkGray
        ButtonDiskon.DisabledState.FillColor = Color.FromArgb(CByte(169), CByte(169), CByte(169))
        ButtonDiskon.DisabledState.ForeColor = Color.FromArgb(CByte(141), CByte(141), CByte(141))
        ButtonDiskon.Dock = DockStyle.Fill
        ButtonDiskon.FillColor = Color.FromArgb(CByte(255), CByte(128), CByte(0))
        ButtonDiskon.Font = New Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point)
        ButtonDiskon.ForeColor = Color.White
        ButtonDiskon.Location = New Point(363, 3)
        ButtonDiskon.Name = "ButtonDiskon"
        ButtonDiskon.ShadowDecoration.CustomizableEdges = CustomizableEdges16
        ButtonDiskon.Size = New Size(174, 54)
        ButtonDiskon.TabIndex = 8
        ButtonDiskon.Text = "DISKON"
        ' 
        ' ButtonBatal
        ' 
        ButtonBatal.CustomizableEdges = CustomizableEdges17
        ButtonBatal.DisabledState.BorderColor = Color.DarkGray
        ButtonBatal.DisabledState.CustomBorderColor = Color.DarkGray
        ButtonBatal.DisabledState.FillColor = Color.FromArgb(CByte(169), CByte(169), CByte(169))
        ButtonBatal.DisabledState.ForeColor = Color.FromArgb(CByte(141), CByte(141), CByte(141))
        ButtonBatal.Dock = DockStyle.Fill
        ButtonBatal.FillColor = Color.FromArgb(CByte(255), CByte(128), CByte(0))
        ButtonBatal.Font = New Font("Arial", 9F, FontStyle.Bold, GraphicsUnit.Point)
        ButtonBatal.ForeColor = Color.White
        ButtonBatal.Location = New Point(183, 3)
        ButtonBatal.Name = "ButtonBatal"
        ButtonBatal.ShadowDecoration.CustomizableEdges = CustomizableEdges18
        ButtonBatal.Size = New Size(174, 54)
        ButtonBatal.TabIndex = 7
        ButtonBatal.Text = "BATALKAN TRANSAKSI"
        ' 
        ' ButtonBaru
        ' 
        ButtonBaru.CustomizableEdges = CustomizableEdges19
        ButtonBaru.DisabledState.BorderColor = Color.DarkGray
        ButtonBaru.DisabledState.CustomBorderColor = Color.DarkGray
        ButtonBaru.DisabledState.FillColor = Color.FromArgb(CByte(169), CByte(169), CByte(169))
        ButtonBaru.DisabledState.ForeColor = Color.FromArgb(CByte(141), CByte(141), CByte(141))
        ButtonBaru.Dock = DockStyle.Fill
        ButtonBaru.FillColor = Color.FromArgb(CByte(255), CByte(128), CByte(0))
        ButtonBaru.Font = New Font("Arial", 9F, FontStyle.Bold, GraphicsUnit.Point)
        ButtonBaru.ForeColor = Color.White
        ButtonBaru.Location = New Point(3, 3)
        ButtonBaru.Name = "ButtonBaru"
        ButtonBaru.ShadowDecoration.CustomizableEdges = CustomizableEdges20
        ButtonBaru.Size = New Size(174, 54)
        ButtonBaru.TabIndex = 6
        ButtonBaru.Text = "BARU"
        ' 
        ' DataGridView1
        ' 
        DataGridView1.AllowUserToAddRows = False
        DataGridView1.AllowUserToDeleteRows = False
        DataGridView1.BackgroundColor = Color.White
        DataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridView1.Columns.AddRange(New DataGridViewColumn() {Column1, Column2, Column3, Column4, Column5, Column6, Column7, Column8, Column9, Column10})
        DataGridViewCellStyle1.Alignment = DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle1.BackColor = SystemColors.Window
        DataGridViewCellStyle1.Font = New Font("Arial", 10F, FontStyle.Bold, GraphicsUnit.Point)
        DataGridViewCellStyle1.ForeColor = SystemColors.ControlText
        DataGridViewCellStyle1.SelectionBackColor = Color.DarkOrange
        DataGridViewCellStyle1.SelectionForeColor = SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = DataGridViewTriState.False
        DataGridView1.DefaultCellStyle = DataGridViewCellStyle1
        DataGridView1.Dock = DockStyle.Fill
        DataGridView1.GridColor = Color.White
        DataGridView1.Location = New Point(0, 197)
        DataGridView1.Name = "DataGridView1"
        DataGridView1.ReadOnly = True
        DataGridView1.RowHeadersVisible = False
        DataGridView1.RowHeadersWidth = 62
        DataGridView1.RowTemplate.Height = 33
        DataGridView1.Size = New Size(835, 474)
        DataGridView1.TabIndex = 4
        ' 
        ' Column1
        ' 
        Column1.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells
        Column1.HeaderText = "#"
        Column1.MinimumWidth = 8
        Column1.Name = "Column1"
        Column1.ReadOnly = True
        Column1.Width = 57
        ' 
        ' Column2
        ' 
        Column2.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells
        Column2.HeaderText = "Kode Produk"
        Column2.MinimumWidth = 8
        Column2.Name = "Column2"
        Column2.ReadOnly = True
        Column2.Width = 155
        ' 
        ' Column3
        ' 
        Column3.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill
        Column3.HeaderText = "Nama Produk"
        Column3.MinimumWidth = 8
        Column3.Name = "Column3"
        Column3.ReadOnly = True
        ' 
        ' Column4
        ' 
        Column4.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells
        Column4.HeaderText = "Jenis Produk"
        Column4.MinimumWidth = 8
        Column4.Name = "Column4"
        Column4.ReadOnly = True
        Column4.Width = 156
        ' 
        ' Column5
        ' 
        Column5.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells
        Column5.HeaderText = "Satuan"
        Column5.MinimumWidth = 8
        Column5.Name = "Column5"
        Column5.ReadOnly = True
        Column5.Width = 112
        ' 
        ' Column6
        ' 
        Column6.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells
        Column6.HeaderText = "Harga"
        Column6.MinimumWidth = 8
        Column6.Name = "Column6"
        Column6.ReadOnly = True
        Column6.Width = 102
        ' 
        ' Column7
        ' 
        Column7.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells
        Column7.HeaderText = "Pajak%"
        Column7.MinimumWidth = 8
        Column7.Name = "Column7"
        Column7.ReadOnly = True
        Column7.Width = 114
        ' 
        ' Column8
        ' 
        Column8.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells
        Column8.HeaderText = "Sub Total"
        Column8.MinimumWidth = 8
        Column8.Name = "Column8"
        Column8.ReadOnly = True
        Column8.Width = 126
        ' 
        ' Column9
        ' 
        Column9.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells
        Column9.HeaderText = "Jumlah"
        Column9.MinimumWidth = 8
        Column9.Name = "Column9"
        Column9.ReadOnly = True
        Column9.Width = 114
        ' 
        ' Column10
        ' 
        Column10.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells
        Column10.HeaderText = "Total"
        Column10.MinimumWidth = 8
        Column10.Name = "Column10"
        Column10.ReadOnly = True
        Column10.Width = 93
        ' 
        ' LabelHitungKeseluruhan
        ' 
        LabelHitungKeseluruhan.Font = New Font("Arial", 16F, FontStyle.Bold, GraphicsUnit.Point)
        LabelHitungKeseluruhan.ForeColor = Color.FromArgb(CByte(255), CByte(128), CByte(0))
        LabelHitungKeseluruhan.Location = New Point(6, 3)
        LabelHitungKeseluruhan.Name = "LabelHitungKeseluruhan"
        LabelHitungKeseluruhan.Size = New Size(356, 31)
        LabelHitungKeseluruhan.TabIndex = 0
        LabelHitungKeseluruhan.Text = "00.00"
        LabelHitungKeseluruhan.TextAlign = ContentAlignment.TopRight
        ' 
        ' ButtonBayar
        ' 
        ButtonBayar.CustomizableEdges = CustomizableEdges21
        ButtonBayar.DisabledState.BorderColor = Color.DarkGray
        ButtonBayar.DisabledState.CustomBorderColor = Color.DarkGray
        ButtonBayar.DisabledState.FillColor = Color.FromArgb(CByte(169), CByte(169), CByte(169))
        ButtonBayar.DisabledState.ForeColor = Color.FromArgb(CByte(141), CByte(141), CByte(141))
        ButtonBayar.Dock = DockStyle.Bottom
        ButtonBayar.FillColor = Color.FromArgb(CByte(255), CByte(128), CByte(0))
        ButtonBayar.Font = New Font("Arial", 9F, FontStyle.Bold, GraphicsUnit.Point)
        ButtonBayar.ForeColor = Color.White
        ButtonBayar.Location = New Point(0, 429)
        ButtonBayar.Name = "ButtonBayar"
        ButtonBayar.ShadowDecoration.CustomizableEdges = CustomizableEdges22
        ButtonBayar.Size = New Size(425, 45)
        ButtonBayar.TabIndex = 9
        ButtonBayar.Text = "BAYAR"
        ' 
        ' Label7
        ' 
        Label7.Font = New Font("Arial", 10F, FontStyle.Bold, GraphicsUnit.Point)
        Label7.Location = New Point(6, 61)
        Label7.Name = "Label7"
        Label7.Size = New Size(153, 25)
        Label7.TabIndex = 10
        Label7.Text = "Jumlah Barang"
        ' 
        ' Label8
        ' 
        Label8.Font = New Font("Arial", 10F, FontStyle.Bold, GraphicsUnit.Point)
        Label8.Location = New Point(3, 141)
        Label8.Name = "Label8"
        Label8.Size = New Size(125, 25)
        Label8.TabIndex = 11
        Label8.Text = "Total Pajak"
        ' 
        ' Label9
        ' 
        Label9.Font = New Font("Arial", 10F, FontStyle.Bold, GraphicsUnit.Point)
        Label9.Location = New Point(6, 185)
        Label9.Name = "Label9"
        Label9.Size = New Size(125, 25)
        Label9.TabIndex = 12
        Label9.Text = "Total Harga"
        ' 
        ' Label10
        ' 
        Label10.Font = New Font("Arial", 10F, FontStyle.Bold, GraphicsUnit.Point)
        Label10.Location = New Point(8, 228)
        Label10.Name = "Label10"
        Label10.Size = New Size(102, 25)
        Label10.TabIndex = 13
        Label10.Text = "Diskon %"
        ' 
        ' Label11
        ' 
        Label11.Font = New Font("Arial", 10F, FontStyle.Bold, GraphicsUnit.Point)
        Label11.Location = New Point(8, 270)
        Label11.Name = "Label11"
        Label11.Size = New Size(219, 30)
        Label11.TabIndex = 14
        Label11.Text = "Total Keseluruhan"
        ' 
        ' Label12
        ' 
        Label12.Font = New Font("Arial", 10F, FontStyle.Bold, GraphicsUnit.Point)
        Label12.Location = New Point(8, 318)
        Label12.Name = "Label12"
        Label12.Size = New Size(217, 21)
        Label12.TabIndex = 15
        Label12.Text = "Metode Pembayaran"
        ' 
        ' Label13
        ' 
        Label13.Font = New Font("Arial", 10F, FontStyle.Bold, GraphicsUnit.Point)
        Label13.Location = New Point(6, 365)
        Label13.Name = "Label13"
        Label13.Size = New Size(166, 25)
        Label13.TabIndex = 16
        Label13.Text = "Jumlah Diterima"
        ' 
        ' Label14
        ' 
        Label14.Font = New Font("Arial", 10F, FontStyle.Bold, GraphicsUnit.Point)
        Label14.Location = New Point(8, 401)
        Label14.Name = "Label14"
        Label14.Size = New Size(125, 25)
        Label14.TabIndex = 17
        Label14.Text = "Kembalian"
        ' 
        ' LabelJumlahBarang
        ' 
        LabelJumlahBarang.Font = New Font("Arial", 10F, FontStyle.Bold, GraphicsUnit.Point)
        LabelJumlahBarang.Location = New Point(243, 64)
        LabelJumlahBarang.Name = "LabelJumlahBarang"
        LabelJumlahBarang.Size = New Size(112, 19)
        LabelJumlahBarang.TabIndex = 18
        LabelJumlahBarang.Text = "0"
        LabelJumlahBarang.TextAlign = ContentAlignment.MiddleRight
        ' 
        ' LabelTotalPajak
        ' 
        LabelTotalPajak.Font = New Font("Arial", 10F, FontStyle.Bold, GraphicsUnit.Point)
        LabelTotalPajak.Location = New Point(243, 144)
        LabelTotalPajak.Name = "LabelTotalPajak"
        LabelTotalPajak.Size = New Size(112, 19)
        LabelTotalPajak.TabIndex = 24
        LabelTotalPajak.Text = "00.00"
        LabelTotalPajak.TextAlign = ContentAlignment.MiddleRight
        ' 
        ' LabelTotalHarga
        ' 
        LabelTotalHarga.Font = New Font("Arial", 10F, FontStyle.Bold, GraphicsUnit.Point)
        LabelTotalHarga.Location = New Point(243, 188)
        LabelTotalHarga.Name = "LabelTotalHarga"
        LabelTotalHarga.Size = New Size(112, 19)
        LabelTotalHarga.TabIndex = 25
        LabelTotalHarga.Text = "00.00"
        LabelTotalHarga.TextAlign = ContentAlignment.MiddleRight
        ' 
        ' textDiskon
        ' 
        textDiskon.CustomizableEdges = CustomizableEdges23
        textDiskon.DefaultText = ""
        textDiskon.DisabledState.BorderColor = Color.FromArgb(CByte(208), CByte(208), CByte(208))
        textDiskon.DisabledState.FillColor = Color.FromArgb(CByte(226), CByte(226), CByte(226))
        textDiskon.DisabledState.ForeColor = Color.FromArgb(CByte(138), CByte(138), CByte(138))
        textDiskon.DisabledState.PlaceholderForeColor = Color.FromArgb(CByte(138), CByte(138), CByte(138))
        textDiskon.Enabled = False
        textDiskon.FocusedState.BorderColor = Color.FromArgb(CByte(94), CByte(148), CByte(255))
        textDiskon.Font = New Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point)
        textDiskon.HoverState.BorderColor = Color.FromArgb(CByte(94), CByte(148), CByte(255))
        textDiskon.Location = New Point(123, 222)
        textDiskon.Name = "textDiskon"
        textDiskon.PasswordChar = ChrW(0)
        textDiskon.PlaceholderText = ""
        textDiskon.SelectedText = ""
        textDiskon.ShadowDecoration.CustomizableEdges = CustomizableEdges24
        textDiskon.Size = New Size(49, 31)
        textDiskon.TabIndex = 26
        ' 
        ' LabelDiskon
        ' 
        LabelDiskon.Font = New Font("Arial", 10F, FontStyle.Bold, GraphicsUnit.Point)
        LabelDiskon.Location = New Point(243, 231)
        LabelDiskon.Name = "LabelDiskon"
        LabelDiskon.Size = New Size(112, 19)
        LabelDiskon.TabIndex = 27
        LabelDiskon.Text = "00.00"
        LabelDiskon.TextAlign = ContentAlignment.MiddleRight
        ' 
        ' LabelTotalKeseluruhan
        ' 
        LabelTotalKeseluruhan.Font = New Font("Arial", 10F, FontStyle.Bold, GraphicsUnit.Point)
        LabelTotalKeseluruhan.ForeColor = Color.DodgerBlue
        LabelTotalKeseluruhan.Location = New Point(243, 270)
        LabelTotalKeseluruhan.Name = "LabelTotalKeseluruhan"
        LabelTotalKeseluruhan.Size = New Size(112, 19)
        LabelTotalKeseluruhan.TabIndex = 28
        LabelTotalKeseluruhan.Text = "00.00"
        LabelTotalKeseluruhan.TextAlign = ContentAlignment.MiddleRight
        ' 
        ' LabelKembalian
        ' 
        LabelKembalian.Font = New Font("Arial", 10F, FontStyle.Bold, GraphicsUnit.Point)
        LabelKembalian.Location = New Point(243, 401)
        LabelKembalian.Name = "LabelKembalian"
        LabelKembalian.Size = New Size(112, 19)
        LabelKembalian.TabIndex = 30
        LabelKembalian.Text = "00.00"
        LabelKembalian.TextAlign = ContentAlignment.MiddleRight
        ' 
        ' ComboPembayaran
        ' 
        ComboPembayaran.BackColor = Color.Transparent
        ComboPembayaran.CustomizableEdges = CustomizableEdges25
        ComboPembayaran.DrawMode = DrawMode.OwnerDrawFixed
        ComboPembayaran.DropDownStyle = ComboBoxStyle.DropDownList
        ComboPembayaran.FocusedColor = Color.FromArgb(CByte(94), CByte(148), CByte(255))
        ComboPembayaran.FocusedState.BorderColor = Color.FromArgb(CByte(94), CByte(148), CByte(255))
        ComboPembayaran.Font = New Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point)
        ComboPembayaran.ForeColor = Color.FromArgb(CByte(68), CByte(88), CByte(112))
        ComboPembayaran.ItemHeight = 30
        ComboPembayaran.Items.AddRange(New Object() {"TUNAI ", "KARTU KREDIT", "KARTU DEBIT", "E-WALLET", "I-BANKING"})
        ComboPembayaran.Location = New Point(226, 303)
        ComboPembayaran.Name = "ComboPembayaran"
        ComboPembayaran.ShadowDecoration.CustomizableEdges = CustomizableEdges26
        ComboPembayaran.Size = New Size(187, 36)
        ComboPembayaran.TabIndex = 31
        ' 
        ' textJmlDiterima
        ' 
        textJmlDiterima.CustomizableEdges = CustomizableEdges27
        textJmlDiterima.DefaultText = ""
        textJmlDiterima.DisabledState.BorderColor = Color.FromArgb(CByte(208), CByte(208), CByte(208))
        textJmlDiterima.DisabledState.FillColor = Color.FromArgb(CByte(226), CByte(226), CByte(226))
        textJmlDiterima.DisabledState.ForeColor = Color.FromArgb(CByte(138), CByte(138), CByte(138))
        textJmlDiterima.DisabledState.PlaceholderForeColor = Color.FromArgb(CByte(138), CByte(138), CByte(138))
        textJmlDiterima.FocusedState.BorderColor = Color.FromArgb(CByte(94), CByte(148), CByte(255))
        textJmlDiterima.Font = New Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point)
        textJmlDiterima.HoverState.BorderColor = Color.FromArgb(CByte(94), CByte(148), CByte(255))
        textJmlDiterima.Location = New Point(226, 354)
        textJmlDiterima.Name = "textJmlDiterima"
        textJmlDiterima.PasswordChar = ChrW(0)
        textJmlDiterima.PlaceholderText = ""
        textJmlDiterima.SelectedText = ""
        textJmlDiterima.ShadowDecoration.CustomizableEdges = CustomizableEdges28
        textJmlDiterima.Size = New Size(185, 36)
        textJmlDiterima.TabIndex = 32
        ' 
        ' Panel3
        ' 
        Panel3.BackColor = Color.White
        Panel3.Controls.Add(LabelSubtotal)
        Panel3.Controls.Add(Label6)
        Panel3.Controls.Add(textJmlDiterima)
        Panel3.Controls.Add(ComboPembayaran)
        Panel3.Controls.Add(LabelKembalian)
        Panel3.Controls.Add(LabelTotalKeseluruhan)
        Panel3.Controls.Add(LabelDiskon)
        Panel3.Controls.Add(textDiskon)
        Panel3.Controls.Add(LabelTotalHarga)
        Panel3.Controls.Add(LabelTotalPajak)
        Panel3.Controls.Add(LabelJumlahBarang)
        Panel3.Controls.Add(Label14)
        Panel3.Controls.Add(Label13)
        Panel3.Controls.Add(Label12)
        Panel3.Controls.Add(Label11)
        Panel3.Controls.Add(Label10)
        Panel3.Controls.Add(Label9)
        Panel3.Controls.Add(Label8)
        Panel3.Controls.Add(Label7)
        Panel3.Controls.Add(ButtonBayar)
        Panel3.Controls.Add(LabelHitungKeseluruhan)
        Panel3.Dock = DockStyle.Right
        Panel3.Location = New Point(835, 197)
        Panel3.Name = "Panel3"
        Panel3.Size = New Size(425, 474)
        Panel3.TabIndex = 3
        ' 
        ' LabelSubtotal
        ' 
        LabelSubtotal.Font = New Font("Arial", 10F, FontStyle.Bold, GraphicsUnit.Point)
        LabelSubtotal.Location = New Point(243, 106)
        LabelSubtotal.Name = "LabelSubtotal"
        LabelSubtotal.Size = New Size(112, 19)
        LabelSubtotal.TabIndex = 34
        LabelSubtotal.Text = "00.00"
        LabelSubtotal.TextAlign = ContentAlignment.MiddleRight
        ' 
        ' Label6
        ' 
        Label6.Font = New Font("Arial", 10F, FontStyle.Bold, GraphicsUnit.Point)
        Label6.Location = New Point(6, 100)
        Label6.Name = "Label6"
        Label6.Size = New Size(125, 25)
        Label6.TabIndex = 33
        Label6.Text = "Subtotal"
        ' 
        ' Timer1
        ' 
        Timer1.Enabled = True
        ' 
        ' Timer2
        ' 
        Timer2.Enabled = True
        ' 
        ' FormKasir
        ' 
        AutoScaleDimensions = New SizeF(12F, 24F)
        AutoScaleMode = AutoScaleMode.Font
        AutoSize = True
        ClientSize = New Size(1260, 731)
        Controls.Add(DataGridView1)
        Controls.Add(Panel3)
        Controls.Add(TableLayoutPanel1)
        Controls.Add(Panel2)
        Controls.Add(Panel1)
        Font = New Font("Arial", 10F, FontStyle.Bold, GraphicsUnit.Point)
        Icon = CType(resources.GetObject("$this.Icon"), Icon)
        Margin = New Padding(4, 3, 4, 3)
        Name = "FormKasir"
        StartPosition = FormStartPosition.Manual
        Text = "FormKasir"
        WindowState = FormWindowState.Maximized
        Panel1.ResumeLayout(False)
        CType(Guna2PictureBox1, ComponentModel.ISupportInitialize).EndInit()
        Panel2.ResumeLayout(False)
        Panel2.PerformLayout()
        TableLayoutPanel1.ResumeLayout(False)
        CType(DataGridView1, ComponentModel.ISupportInitialize).EndInit()
        Panel3.ResumeLayout(False)
        ResumeLayout(False)
    End Sub

    Friend WithEvents Panel1 As Panel
    Friend WithEvents Panel2 As Panel
    Friend WithEvents TableLayoutPanel1 As TableLayoutPanel
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents Column1 As DataGridViewTextBoxColumn
    Friend WithEvents Column2 As DataGridViewTextBoxColumn
    Friend WithEvents Column3 As DataGridViewTextBoxColumn
    Friend WithEvents Column4 As DataGridViewTextBoxColumn
    Friend WithEvents Column5 As DataGridViewTextBoxColumn
    Friend WithEvents Column6 As DataGridViewTextBoxColumn
    Friend WithEvents Column7 As DataGridViewTextBoxColumn
    Friend WithEvents Column8 As DataGridViewTextBoxColumn
    Friend WithEvents Column9 As DataGridViewTextBoxColumn
    Friend WithEvents Column10 As DataGridViewTextBoxColumn
    Friend WithEvents Guna2PictureBox1 As Guna.UI2.WinForms.Guna2PictureBox
    Friend WithEvents Label5 As Label
    Friend WithEvents Text_CariProduk_Barcode As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents textNoTagihan As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Guna2DateTimePicker1 As Guna.UI2.WinForms.Guna2DateTimePicker
    Friend WithEvents ButtonBaru As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents ButtonLogout As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents ButtonUbahPassword As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents ButtonHapus As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents ButtonLaporan As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents ButtonDiskon As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents ButtonBatal As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents LabelHitungKeseluruhan As Label
    Friend WithEvents ButtonBayar As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents LabelJumlahBarang As Label
    Friend WithEvents LabelTotalPajak As Label
    Friend WithEvents LabelTotalHarga As Label
    Friend WithEvents textDiskon As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents LabelDiskon As Label
    Friend WithEvents LabelTotalKeseluruhan As Label
    Friend WithEvents LabelKembalian As Label
    Friend WithEvents ComboPembayaran As Guna.UI2.WinForms.Guna2ComboBox
    Friend WithEvents textJmlDiterima As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Panel3 As Panel
    Friend WithEvents Timer1 As Timer
    Friend WithEvents LabelSubtotal As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents LabelWaktu As Label
    Friend WithEvents LabelTanggal As Label
    Friend WithEvents Timer2 As Timer
    Friend WithEvents WaktuTanggal As DateTimePicker
End Class
